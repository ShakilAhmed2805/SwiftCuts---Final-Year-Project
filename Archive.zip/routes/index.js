var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


//About Page
router.get('/about', function(req, res, next) {
      res.render('about', { title: 'About Us' });
});



//Contact Page
router.get('/contact', function(req, res, next) {
    res.render('contact', { title: 'Contact' });
});


//Sign up Page
router.get('/signup', function(req, res, next) {

    res.render('signup', { title: 'Sign UP' });
});

//Sign up post Page
router.post('/signup', function(req, res, next) {
   res.send(req.body);
});


//Login Page
router.get('/login', function(req, res, next) {

        res.render('login', { title: 'Login' });
});

//Login post Page
router.post('/login', function(req, res, next) {
    res.send(req.body);
});


//Post request for subscribe newsletter
router.post('/subscribe', function(req, res, next) {
    res.send(req.body);
});


module.exports = router;
