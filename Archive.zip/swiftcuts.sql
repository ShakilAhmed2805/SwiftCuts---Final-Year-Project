use swiftcuts;
create table users(
id INT PRIMARY KEY auto_increment,
first_name VARCHAR(100) not null,
last_name VARCHAR(100) NOT NULL,
email VARCHAR(100) NOT NULL,
password VARCHAR(500) NOT NULL,
mobile VARCHAR(20),
dob DATE,
age INT,
address varchar(100),
city VARCHAR(50),
post_code VARCHAR(10),
last_login datetime,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT current_timestamp on update current_timestamp
);

CREATE USER 'swiftcuts'@'localhost' identified BY 'swiftcuts';
GRANT ALL privileges on swiftcuts.* to 'swiftcuts'@'localhost';